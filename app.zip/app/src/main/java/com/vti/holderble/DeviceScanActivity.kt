package com.vti.holderble

import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.IntentSender
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.PendingResult
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.*


class DeviceScanActivity : AppCompatActivity(), GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener {
    private var googleApiClient: GoogleApiClient? = null

    //    private var adapter : LeDeviceListAdapter
//    private var rcvDeviceScan
    private var scanning = false
    private var handler = Handler()
    private var bluetoothLeAdapter: BluetoothAdapter? = null
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private val SCAN_PERIOD: Long = 30000
    private var leDeviceListAdapter = LeDeviceListAdapter(this)
    private var rcvDeviceScan: RecyclerView? = null
    private var permissions = listOf(android.Manifest.permission.ACCESS_FINE_LOCATION)

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.devive_scan_activity)
        rcvDeviceScan = findViewById(R.id.rcvDeviceScan)
        rcvDeviceScan?.setHasFixedSize(true)
        rcvDeviceScan?.adapter = leDeviceListAdapter
        bluetoothLeAdapter = BluetoothAdapter.getDefaultAdapter()
        displayLocationSettings(this@DeviceScanActivity)
        requestPermission()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bluetoothLeScanner = bluetoothLeAdapter?.bluetoothLeScanner
        }
        scanDevice()
    }

    private fun requestPermission() {

        permissions.forEach {
            if (ContextCompat.checkSelfPermission(
                    this@DeviceScanActivity,
                    it
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this@DeviceScanActivity,
                    permissions.toTypedArray(),
                    1997
                )

            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) run {
            displayLocationSettings(this@DeviceScanActivity)
        }
    }

    private fun displayLocationSettings(context: Context) {
        googleApiClient = GoogleApiClient.Builder(context)
            .addApi(LocationServices.API).addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .build()

        googleApiClient?.connect()

    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun scanDevice() {
        if (!scanning) {
            handler.postDelayed(
                {
                    scanning = false
                    bluetoothLeScanner?.stopScan(leScanCallBack)
                }, SCAN_PERIOD
            )
            scanning = true
            bluetoothLeScanner?.startScan(leScanCallBack)
        } else {
            scanning = false
            bluetoothLeScanner?.stopScan(leScanCallBack)
        }
    }

    private val leScanCallBack: ScanCallback = @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            super.onScanResult(callbackType, result)
            val devices = result?.device
            devices?.let { leDeviceListAdapter.addDevice(device = it) }
            val deviceAddress = devices?.address
            leDeviceListAdapter.notifyDataSetChanged()
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Toast.makeText(this@DeviceScanActivity, errorCode.toString(), Toast.LENGTH_SHORT).show()
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            super.onBatchScanResults(results)
        }

    }

    override fun onConnected(p0: Bundle?) {
        val locationRequest = LocationRequest.create()
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        locationRequest.interval = 10000
        locationRequest.fastestInterval = (locationRequest.interval) / 2
        val settingsRequest = LocationSettingsRequest.Builder().addLocationRequest(locationRequest)
        settingsRequest.setAlwaysShow(true)
        val result: PendingResult<LocationSettingsResult> =
            LocationServices.SettingsApi.checkLocationSettings(
                googleApiClient,
                settingsRequest.build()
            )
        result.setResultCallback {
                val status = it.status
                status.startResolutionForResult(this@DeviceScanActivity,1997)
        }
    }

    override fun onConnectionSuspended(p0: Int) {

    }

    override fun onConnectionFailed(p0: ConnectionResult) {

    }

    private fun enableLoc() {
        googleApiClient = GoogleApiClient.Builder(this)
            .addApi(LocationServices.API)
            .addConnectionCallbacks(object : GoogleApiClient.ConnectionCallbacks {
                override fun onConnected(bundle: Bundle?) {}
                override fun onConnectionSuspended(i: Int) {
                    googleApiClient?.connect()
                }
            })
            .addOnConnectionFailedListener {
            }.build()
        googleApiClient?.connect()
        val locationRequest = LocationRequest.create()
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        locationRequest.interval = 30 * 1000.toLong()
        locationRequest.fastestInterval = 5 * 1000.toLong()
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
        builder.setAlwaysShow(true)
        val result: PendingResult<LocationSettingsResult> =
            LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build())
        result.setResultCallback { result ->
            val status: Status = result.status
            when (status.statusCode) {
                LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> try {
                    status.startResolutionForResult(
                        this@DeviceScanActivity,
                        1997
                    )
                } catch (e: IntentSender.SendIntentException) {
                }
            }
        }

    }
}