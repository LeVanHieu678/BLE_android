package com.vti.holderble

import android.app.Service
import android.bluetooth.BluetoothGattService
import android.content.*
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vti.holderble.service.BluetoothLeService

class DeviceControllerActivity : AppCompatActivity() {
    private var connected = false
    private var bluetoothService: BluetoothLeService? = null

    private val serviceConnection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            bluetoothService = (service as BluetoothLeService.LocalBinder).getService()
            bluetoothService?.let { bluetooth ->
                if (!bluetooth.initialize()) {
                    Toast.makeText(
                        this@DeviceControllerActivity,
                        "Unable to initialize Bluetooth",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                }
//                bluetooth.connect(address = deviceAddress)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bluetoothService = null
        }

    }
    private val gattUpdaterReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothLeService.ACTION_GATT_CONNECTED -> {
                    connected = true
//                    updateConnectionState(R.string.connected)
                }
                BluetoothLeService.ACTION_GATT_DISCONNECTED -> {
                    connected = false
//                    updateConnectionState(R.string.disconnected)
                }
                BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED ->{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                        displayGattService(bluetoothService?.getSupportedGattServices())
                    }
                }
            }
        }
    }

    private fun displayGattService(gattServices: MutableList<BluetoothGattService>?) {
        if (gattServices == null) return

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gatt_services_characteristics)
        val gattServerIntent = Intent(this, BluetoothLeService::class.java)
        bindService(gattServerIntent, serviceConnection, Service.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(gattUpdaterReceiver, makeGattUpdateIntentFilter())
    }

    private fun makeGattUpdateIntentFilter(): IntentFilter? {
        return IntentFilter().apply {
            addAction(BluetoothLeService.ACTION_GATT_CONNECTED)
            addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED)

        }
    }


}
